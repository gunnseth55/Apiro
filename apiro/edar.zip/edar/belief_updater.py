"""
apiro/edar/belief_updater.py
=============================
Phase 3: Iterative Bayesian Belief Revision.

This is the core "thinking" of the EDAR engine. Unlike the HT engine's
cosine similarity ranking, this module performs genuine probabilistic
reasoning: each piece of evidence from the patient's presentation updates
the posterior probability of each candidate disease via Bayes' rule.

Algorithm:
  - Start with uniform prior P(Disease_i) = 1/N for all N candidates.
  - For each expected finding F of Disease D:
      * If F is CONFIRMED in patient: multiply P(D) by BOOST_FACTOR
      * If F is ABSENT (expected but missing): multiply P(D) by ABSENT_PENALTY
      * If F is CONTRADICTED: multiply P(D) by CONTRADICT_PENALTY
  - Normalize all posteriors to sum to 1.0 after all updates.
  - Apply a demographic prior: age/gender-based prevalence correction.

The iterative multiplicative update is a simplified log-linear Bayesian
model equivalent to Naive Bayes with log-space accumulation, which is
statistically principled for independent binary evidence features.

Zero LLM calls.
"""

from __future__ import annotations

import logging
import math
from typing import Optional

from apiro.edar.evidence_graph import EvidenceNode
from apiro.patient.context import PatientContext

logger = logging.getLogger(__name__)

# ── Belief update factors ──────────────────────────────────────────────────────
# These are log-space factors (interpretable as likelihood ratios):
_CONFIRM_BOOST     = 1.40   # confirmed expected finding → boost  (LR ≈ 1.4×)
_ABSENT_PENALTY    = 0.82   # absent expected finding   → mild penalty
_CONTRADICT_PENALTY = 0.20  # contradicted finding      → strong penalty

# Minimum posterior to prevent numerical underflow
_MIN_POSTERIOR = 1e-9




class BayesianBeliefUpdater:
    """
    Applies iterative Bayesian evidence updates to a set of EvidenceNodes,
    producing final posterior probabilities for each candidate disease.

    The update is fully transparent: each step logs why a disease's
    probability rose or fell. This is the "reasoning trace" of EDAR.

    Args:
        confirm_boost:      Likelihood multiplier for a confirmed finding.
        absent_penalty:     Likelihood multiplier for an absent finding.
        contradict_penalty: Likelihood multiplier for a contradicted finding.
        age_prior:          Whether to apply age-based prevalence correction.
    """

    def __init__(
        self,
        confirm_boost:      float = _CONFIRM_BOOST,
        absent_penalty:     float = _ABSENT_PENALTY,
        contradict_penalty: float = _CONTRADICT_PENALTY,
        age_prior:          bool = True,
    ):
        self.confirm_boost      = confirm_boost
        self.absent_penalty     = absent_penalty
        self.contradict_penalty = contradict_penalty
        self.age_prior          = age_prior

    def _compute_age_prior(self, disease: str, context: PatientContext) -> float:
        """
        Simple age-based prevalence correction.
        Penalises paediatric diseases in adults and vice versa.
        Returns a multiplier [0.1, 1.0].
        """
        if not context.age or not self.age_prior:
            return 1.0

        try:
            age = int(str(context.age).split()[0])
        except (ValueError, IndexError):
            return 1.0

        disease_lower = disease.lower()

        # Penalise clearly paediatric diseases in adults
        paediatric_terms = [
            "childhood", "paediatric", "pediatric", "juvenile", "neonatal",
            "infant", "congenital", "kawasaki", "wilms", "neuroblastoma",
            "dravet", "duchenne", "legg-calve", "osteosarcoma",
        ]
        if age > 18 and any(t in disease_lower for t in paediatric_terms):
            return 0.25

        # Penalise adult diseases in children
        adult_terms = [
            "alzheimer", "atherosclerosis", "coronary artery disease", "copd",
            "type 2 diabetes", "benign prostatic", "osteoporosis", "gout",
        ]
        if age < 15 and any(t in disease_lower for t in adult_terms):
            return 0.30

        return 1.0

    def update(
        self,
        evidence_graph: dict[str, EvidenceNode],
        context: Optional[PatientContext] = None,
    ) -> list[tuple[str, float, EvidenceNode]]:
        """
        Apply iterative Bayesian evidence updates to all disease candidates.

        Args:
            evidence_graph: Dict of disease_name → EvidenceNode
            context:        PatientContext for demographic priors

        Returns:
            Sorted list of (disease_name, posterior, EvidenceNode), highest first.
        """
        diseases = list(evidence_graph.keys())
        n = len(diseases)
        if n == 0:
            return []

        # ── Uniform prior ────────────────────────────────────────────────────
        posteriors: dict[str, float] = {d: 1.0 / n for d in diseases}

        # ── Iterative Bayesian update ─────────────────────────────────────────
        for disease, node in evidence_graph.items():
            # Start with log-space accumulation to avoid underflow
            import math
            log_p = math.log(posteriors[disease])

            n_expected = len(node.expected_findings)

            # If no expected findings found in corpus — neutral (no info)
            if n_expected == 0:
                continue

            # Each confirmed finding is strong positive evidence
            for finding in node.confirmed:
                log_p += math.log(self.confirm_boost)

            # Each absent finding is mild negative evidence
            # Weight by how clinically significant it is (all equally for now)
            for finding in node.absent:
                log_p += math.log(self.absent_penalty)

            # Each contradiction is devastating
            for finding in node.contradicted:
                log_p += math.log(self.contradict_penalty)

            # Apply age/demographic prior
            if context is not None:
                age_factor = self._compute_age_prior(disease, context)
                if age_factor != 1.0:
                    log_p += math.log(age_factor)

            # Bonus: reward diseases that actually have confirmed findings
            # This prevents diseases with very few expected findings from winning
            # purely by avoiding absent-finding penalties
            if len(node.confirmed) == 0 and n_expected > 0:
                # Zero confirmed out of N expected — add extra penalty
                log_p += math.log(0.5)

            posteriors[disease] = max(math.exp(log_p), _MIN_POSTERIOR)
            node.posterior = posteriors[disease]

        # ── Normalise to sum to 1 ────────────────────────────────────────────
        total = sum(posteriors.values())
        if total > 0:
            for d in posteriors:
                posteriors[d] /= total
                evidence_graph[d].posterior = posteriors[d]

        # ── Sort and return ──────────────────────────────────────────────────
        ranked = sorted(
            [(d, posteriors[d], evidence_graph[d]) for d in diseases],
            key=lambda x: -x[1],
        )

        logger.info(
            f"[BayesianBeliefUpdater] Ranked {len(ranked)} candidates. "
            f"Top 3: {[(r[0][:40], round(r[1], 4)) for r in ranked[:3]]}"
        )

        return ranked
